<x-app-layout>
    <main class="p-4 sm:ml-64 h-full">
        <div class="p-4 mt-10">
        <p>Dashboard</p>
        </div>
    </main>
</x-app-layout>