<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @vite('resources/css/app.css')
    <title>Estudio Jurídico Mallón y Asociados</title>

</head>

<body class="h-screen w-screen">
    <header>

    </header>

    
    <x-nav-bar>

    </x-nav-bar>

    <x-sidebar>

    </x-sidebar>

    {{ $slot }}

    
     
</body>

</html>
