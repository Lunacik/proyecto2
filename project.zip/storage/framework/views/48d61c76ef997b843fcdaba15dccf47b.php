<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <main class="p-4 sm:ml-64 h-full">
        <div class="p-4 mt-10">
            <div class="flex justify-center">
                <h6 class="text-lg font-bold">Formulario de creacion casos</h6>
            </div>
            <form class="max-w-md mx-auto" method="POST" action="/casos">
                <?php echo csrf_field(); ?>

                <div class=" flex flex-col gap-4">
                    <div>
                        <label for="underline_select" class="sr-only">Underline select</label>
                        <select id="underline_select" name="ciabogado"
                            class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none 
                        dark:text-gray-400 focus:outline-none focus:ring-0 focus:border-gray-200 peer">
                            <option value="" selected>Seleccion un abogado</option>

                            <?php $__currentLoopData = $abogados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abogado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($abogado->ci); ?>"><?php echo e($abogado->usuario->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>

                    <div>
                        <label for="underline_select" class="sr-only">Underline select</label>

                        <select id="underline_select" name="codcliente"
                            class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2
                         border-gray-200 appearance-none dark:text-gray-400  focus:outline-none focus:ring-0
                          focus:border-gray-200 peer">

                            <option value="" selected>Seleccione al cliente</option>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cliente->ci); ?>"><?php echo e($cliente->usuario->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <div>
                        <label for="underline_select" class="sr-only">Underline select</label>

                        <select id="underline_select" name="codservicio"
                            class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2
                         border-gray-200 appearance-none dark:text-gray-400  focus:outline-none focus:ring-0
                          focus:border-gray-200 peer">

                            <option value="" selected>Seleccione el servicio</option>
                            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($servicio->codigo); ?>"><?php echo e($servicio->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <button type="submit"
                        class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none 
            focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center
            ">Crear</button>

                </div>



            </form>
        </div>
    </main>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\MSI SWORD 15 A12V\Desktop\laravel\tecno-web\TestOne\resources\views/casos/create.blade.php ENDPATH**/ ?>